# Telegram Stars Donate Bot for Vercel

Deploy to Vercel, set ENV variables, then open /api/setup?key=YOUR_KEY to activate webhook.
