const BOT_TOKEN = process.env.BOT_TOKEN;
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || "";
const SETUP_KEY = process.env.SETUP_KEY || "";

function apiUrl(method) {
  return `https://api.telegram.org/bot${BOT_TOKEN}/${method}`;
}

async function tg(method, body) {
  const res = await fetch(apiUrl(method), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json();
  if (!json.ok) throw new Error(json.description);
  return json.result;
}

module.exports = async (req, res) => {
  if (req.query.key !== SETUP_KEY) {
    res.status(403).send("forbidden");
    return;
  }

  const host = req.headers.host;
  const url = `https://${host}/api/telegram`;

  try {
    await tg("setWebhook", {
      url,
      secret_token: WEBHOOK_SECRET,
      drop_pending_updates: true
    });

    res.status(200).send("Webhook set OK");
  } catch (e) {
    res.status(500).send(e.message);
  }
};
