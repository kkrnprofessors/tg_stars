const AMOUNTS = [500, 1000, 1500, 2000, 3000, 4000, 5000];

function numEnv(name, def = 0) {
  const v = process.env[name];
  if (!v) return def;
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

const BOT_TOKEN = process.env.BOT_TOKEN;
const ADMIN_USER_ID = numEnv("ADMIN_USER_ID", 0);
const LOG_CHAT_ID = numEnv("LOG_CHAT_ID", 0);
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || "";

function apiUrl(method) {
  return `https://api.telegram.org/bot${BOT_TOKEN}/${method}`;
}

async function tg(method, body) {
  const res = await fetch(apiUrl(method), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => null);
  if (!json || !json.ok) {
    const desc = json?.description || "Unknown Telegram API error";
    throw new Error(`${method} failed: ${desc}`);
  }
  return json.result;
}

function isAdmin(userId) {
  return ADMIN_USER_ID > 0 && userId === ADMIN_USER_ID;
}

function donateKeyboard() {
  const rows = [];
  for (let i = 0; i < AMOUNTS.length; i += 2) {
    const row = AMOUNTS.slice(i, i + 2).map((a) => ({
      text: `${a} ⭐`,
      callback_data: `donate:${a}`,
    }));
    rows.push(row);
  }
  return { inline_keyboard: rows };
}

module.exports = async (req, res) => {
  if (!BOT_TOKEN) {
    res.status(500).send("BOT_TOKEN missing");
    return;
  }

  if (WEBHOOK_SECRET) {
    const secret = req.headers["x-telegram-bot-api-secret-token"];
    if (secret !== WEBHOOK_SECRET) {
      res.status(403).send("forbidden");
      return;
    }
  }

  const update = req.body;
  res.status(200).send("ok");

  try {
    if (update.pre_checkout_query) {
      await tg("answerPreCheckoutQuery", {
        pre_checkout_query_id: update.pre_checkout_query.id,
        ok: true,
      });
      return;
    }

    const sp = update.message?.successful_payment;
    if (sp) {
      const chatId = update.message.chat.id;
      const total = sp.total_amount;

      await tg("sendMessage", {
        chat_id: chatId,
        text: `✅ Получено ${total} ⭐ Спасибо!`,
      });

      if (LOG_CHAT_ID) {
        await tg("sendMessage", {
          chat_id: LOG_CHAT_ID,
          text: `💫 Stars payment\nuser_id: ${update.message.from.id}\namount: ${total} ⭐`
        });
      }
      return;
    }

    const text = update.message?.text;
    if (text) {
      const chatId = update.message.chat.id;
      const userId = update.message.from?.id;

      if (text === "/start" || text.startsWith("/donate")) {
        await tg("sendMessage", {
          chat_id: chatId,
          text: "Выбери сумму поддержки:",
          reply_markup: donateKeyboard(),
        });
        return;
      }

      if (text.startsWith("/balance")) {
        if (!isAdmin(userId)) return;
        const bal = await tg("getMyStarBalance", {});
        await tg("sendMessage", {
          chat_id: chatId,
          text: JSON.stringify(bal, null, 2),
        });
        return;
      }
    }

    const cq = update.callback_query;
    if (cq) {
      const data = cq.data || "";
      const chatId = cq.message?.chat?.id;

      if (data.startsWith("donate:") && chatId) {
        const amount = Number(data.split(":")[1]);

        await tg("answerCallbackQuery", { callback_query_id: cq.id });

        await tg("sendInvoice", {
          chat_id: chatId,
          title: "Поддержка проекта",
          description: `Поддержка на ${amount} Stars`,
          payload: `donate_${amount}_${Date.now()}`,
          provider_token: "",
          currency: "XTR",
          prices: [{ label: "Support", amount }],
        });
      }
    }
  } catch (e) {
    console.error(e);
  }
};
